#include "passage.h"

void Passage::command(Story* ins)
{
	cout << getText();
}
