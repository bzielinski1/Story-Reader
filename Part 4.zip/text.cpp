#include "text.h"

void Text::command(Story* ins)
{
	cout << endl << "Text: \"" << getText() << "\"" << endl;
}
