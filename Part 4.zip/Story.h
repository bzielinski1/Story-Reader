#ifndef STORY_H
#define STORY_H

#include <iostream>
#include <vector>
#include <unordered_map>
#include "storytokenizer.h"


using namespace std;
class link;
class Story
{
	private:
		int pos = 0;
	public:
		unordered_map<string, int> pas;
		vector<PassageToken> passages;
		Story(string);
		void print();
		int getPos() { return pos; };
		void setPos(int x) { pos = x; };
};

#endif