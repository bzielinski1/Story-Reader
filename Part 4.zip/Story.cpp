#include "Story.h"
#include "goto.h"
#include "ifs.h"
#include "C:\Users\blain\source\repos\Project1_part1\Project1_part1\link.h"
#include "set.h"
#include "text.h"
#include "passage.h"
#include <iostream>
#include <istream>
#include <vector>
#include <fstream>
#include <string> 
Story::Story(string file_name)
{
	string story, line;
	ifstream in(file_name);
	if (!in.is_open())
	{
		cout << "Couldn't open " << file_name << " for reading!\n";
	}

	getline(in, line);
	while (in && line != "</html>")
	{
		story += line + '\n';
		getline(in, line);
	}

	StoryTokenizer st(story);

	while (st.hasNextPassage())
	{
		PassageToken ptok = st.nextPassage();
		pas.emplace(ptok.getName(), passages.size());
		passages.push_back(ptok);
	}
}

void Story::print()
{
	for (int i = 0; i < passages.size(); i++)
	{

		PassageTokenizer ptok(passages[i].getText());
		cout << endl << "Passage " << passages[i].getName() << ":";
		while (ptok.hasNextPart())
		{
			PartToken stok(ptok.nextPart());

			if (stok.getType() == IF || stok.getType() == ELSEIF || stok.getType() == ELSE)
			{
				string copy = stok.getText();
				stok = ptok.nextPart();
				Ifs ifs(copy, stok.getText());
				cout << "If" << ":  var=" << ifs.getVar();
				if (ifs.getVal())
					cout << ", value=true";
				else
					cout << ", value=false";
				cout << endl << "START BLOCK";
				stok = ptok.nextPart();

				//if there are any elseif/else related to the previous if statement, that gets added to the queue as well
				while (stok.getType() == IF || stok.getType() == ELSE || stok.getType() == ELSEIF)
				{
					copy = stok.getText();
					stok = ptok.nextPart();
					Ifs extra(copy, stok.getText());
				}


				if (stok.getType() == SET)
				{
					Set st(stok.getText());
					st.command(this);
				}
				else if (stok.getType() == TEXT)
				{
					cout << endl << "Text:  \"" << ifs.getStatement() << "\"" << endl << "END BLOCK";
					Text tx(stok.getText());
					tx.command(this);
				}
				else if (stok.getType() == LINK)
				{
					Link* link = new Link(stok.getText());
					cout << "Link: display=" << link->getText() << ", target=" << link->getText();
				}
				else if (stok.getType() == GOTO)
				{
					Goto gt(stok.getText());
					gt.command(this);
				}


			}
			else if (stok.getType() == SET)
			{
				Set st(stok.getText());
				st.command(this);
			}
			else if (stok.getType() == TEXT)
			{
				Text tx(stok.getText());
				tx.command(this);
			}
			else if (stok.getType() == LINK)
			{
				Link* link = new Link(stok.getText());
				cout << "link: display=" << link->getText() << ", target=" << link->getText();
			}
			else if (stok.getType() == GOTO)
			{
				Goto gt(stok.getText());
				gt.command(this);
			}
		}
	}
}
